﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts
{
    class PhoneBookLoader
    {
        public void loadDataFromFile (PhoneBook phoneBook, string fileName)
        {
            if ( File.Exists(fileName) )
            {
                StreamReader sr = File.OpenText(fileName);

                List<Contact> phoneBookList = new List<Contact>( );

                while ( true )
                {
                    string stringInFile = sr.ReadLine( );

                    if ( stringInFile == null ) { break; }

                    string [ ] nameAndPhone = stringInFile.Split(new char [ ] { '|' });

                    phoneBookList.Add(new Contact(nameAndPhone [ 0 ], nameAndPhone [ 1 ]));
                }

                phoneBook.phoneBookList = phoneBookList;

                sr.Close( );
            }
        }

        public void saveDataInFile (PhoneBook phoneBook, string fileName) {
            if ( File.Exists(fileName) )
            {
                StreamWriter sw = File.CreateText(fileName);

                foreach ( var user in phoneBook.phoneBookList )
                {
                    sw.WriteLine($"{user.Name}|{user.Phone}");
                }

                sw.Close( );
            }
        }

    }
}
