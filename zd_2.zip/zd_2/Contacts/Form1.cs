﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contacts
{
    public partial class Form1 :Form
    {
        public string checkingString (string text, string field)
        {
            string message = "";

            if ( text == "" )
            {
                message = $"Поле {field} нужно заполнить!";
            }
            else if(text.Length < 2)
            {
                message = $"Поле {field} должно содержать больше 5 символов!";
            }
            else
            {
                foreach ( var letter in text )
                {
                    int num;

                    if ( !char.IsLetter(letter) )
                    {
                        message = "Можно вводить только буквы!";
                    }
                }
            }

            return message;
        }
        public string checkingNumberINp (string text, string field)
        {
            string message = "";

            if ( text == "" )
            {
                message = $"Поле {field} нужно заполнить!";
            }
            else if ( text.Length < 2 )
            {
                message = $"Поле {field} должно содержать 14 символов!";
            }
            else
            {
                foreach ( var letter in text )
                {
                    int num;

                    if ( char.IsNumber(letter) || letter == '(' || letter == ')' )
                    {
                    }
                    else
                    {
                        message = "Можно вводить только буквы и цифры!";
                    }
                }
            }

            return message;
        }

        public string checkingNumber (string text, string field)
        {
            string message = "";

            if ( text == "" )
            {
                message = $"Поле {field} нужно заполнить!";
            }
            else if ( text.Length != 14 )
            {
                message = $"Поле {field} должно содержать 14 символов!";
            }
            else
            {
                foreach ( var letter in text )
                {
                    int num;

                    if ( char.IsNumber(letter) || letter == '(' || letter == ')' )
                    {
                    }
                    else
                    {
                        message = "Можно вводить только буквы и цифры!";
                    }
                }
            }

            return message;
        }

        PhoneBookLoader fileMethods = new PhoneBookLoader( );
        PhoneBook phoneBook = new PhoneBook( );

        List<Contact> phoneBookList = new List<Contact>( );

        public Form1 ()
        {
            InitializeComponent( );
        }

        private void Form1_Load (object sender, EventArgs e)
        {
            fileMethods.loadDataFromFile(phoneBook, "Контакты.txt");

            List<string> nameAndPhone = new List<string>( );

            foreach ( var user in phoneBook.phoneBookList )
            {
                nameAndPhone.Add($"Имя: {user.Name}. Номер: {user.Phone}.");
            }

            listBox1.Items.AddRange(nameAndPhone.ToArray( ));
        }

        private void button5_Click (object sender, EventArgs e)
        {
            Application.Exit( );
        }

        private void button1_Click (object sender, EventArgs e)
        {
            try
            {
                string errorMessage1 = checkingString(textBox1.Text, "поиск по имени");

                if ( errorMessage1 != "" )
                {
                    throw new Exception(errorMessage1);
                }



                phoneBook.searchedList = new List<Contact>( );

                phoneBook.searchContactByName(textBox1.Text);

                listBox1.Items.Clear( );

                List<string> searchedNamesAndPhones = new List<string>( );

                foreach ( var user in phoneBook.searchedList )
                {
                    searchedNamesAndPhones.Add($"Имя: {user.Name}. Номер: {user.Phone}.");
                }

                listBox1.Items.AddRange(searchedNamesAndPhones.ToArray( ));

                textBox1.Text = "";
            }
            catch ( Exception error )
            {
                MessageBox.Show(
                    error.Message,
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }

        private void button8_Click (object sender, EventArgs e)
        {
            try
            {
                string errorMessage2 = checkingNumberINp(textBox4.Text, "поиск по телефону");

                if ( errorMessage2 != "" )
                {
                    throw new Exception(errorMessage2);
                }

                phoneBook.searchedList = new List<Contact>( );

                phoneBook.searchContactByPhone(textBox4.Text);

                listBox1.Items.Clear( );

                List<string> searchedNamesAndPhones = new List<string>( );

                foreach ( var user in phoneBook.searchedList )
                {
                    searchedNamesAndPhones.Add($"Имя: {user.Name}. Номер: {user.Phone}.");
                }

                listBox1.Items.AddRange(searchedNamesAndPhones.ToArray( ));

                textBox4.Text = "";
            }
            catch ( Exception error )
            {
                MessageBox.Show(
                    error.Message,
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }

        private void button6_Click (object sender, EventArgs e)
        {
            listBox1.Items.Clear( );

            List<string> nameAndPhone = new List<string>( );

            foreach ( var user in phoneBook.phoneBookList )
            {
                nameAndPhone.Add($"Имя: {user.Name}. Номер: {user.Phone}.");
            }

            listBox1.Items.AddRange(nameAndPhone.ToArray( ));
        }

        private void button2_Click (object sender, EventArgs e)
        {
            try
            {
                string errorMessage1 = checkingString(textBox2.Text, "имя и фамилия");

                if ( errorMessage1 != "" )
                {
                    throw new Exception(errorMessage1);
                }

                string errorMessage2 = checkingNumber(textBox3.Text, "номер");

                if ( errorMessage2 != "" )
                {
                    throw new Exception(errorMessage2);
                }

                phoneBook.addContact(textBox2.Text, textBox3.Text);

                List<string> nameAndPhone = new List<string>( );

                foreach ( var user in phoneBook.phoneBookList )
                {
                    nameAndPhone.Add($"Имя: {user.Name}. Номер: {user.Phone}.");
                }

                listBox1.Items.Clear( );

                listBox1.Items.AddRange(nameAndPhone.ToArray( ));

                textBox2.Text = "";
                textBox3.Text = "";
            }
            catch ( Exception error )
            {
                MessageBox.Show(
                    error.Message,
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }

        private void button4_Click (object sender, EventArgs e)
        {
            fileMethods.saveDataInFile(phoneBook, "Контакты.txt");
        }

        private void button3_Click (object sender, EventArgs e)
        {
            if( listBox1.SelectedIndex != -1)
            {
                phoneBook.deleteContact( listBox1.SelectedIndex);

                listBox1.Items.Clear( );

                List<string> nameAndPhone = new List<string>( );

                foreach ( var user in phoneBook.phoneBookList )
                {
                    nameAndPhone.Add($"Имя: {user.Name}. Номер: {user.Phone}.");
                }

                listBox1.Items.AddRange(nameAndPhone.ToArray( ));
            } else
            {
                MessageBox.Show(
                    "Выберите контакт чтобы удалить его!",
                    "Ошибка",
                    MessageBoxButtons.OK);
            }
        }

        private void textBox2_TextChanged (object sender, EventArgs e)
        {

        }
    }
}
