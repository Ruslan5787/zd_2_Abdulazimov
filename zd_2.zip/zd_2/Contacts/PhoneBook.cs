﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts
{
    class PhoneBook
    {
        public List<Contact> phoneBookList;
        public List<Contact> searchedList = new List<Contact>();

        public void searchContactByName(string searchText)
        {
            foreach ( var user in phoneBookList )
            {
                if( user.Name.Contains(searchText))
                {
                    searchedList.Add(user);
                }
            }
        }

        public void searchContactByPhone (string searchText)
        {
            foreach ( var user in phoneBookList )
            {
                if ( user.Phone.Contains(searchText) )
                {
                    searchedList.Add(user);
                }
            }
        }

        public void addContact (string name, string phone)
        {
            Contact newContact = new Contact(name, phone);

            phoneBookList.Add(newContact);
        }

        public void deleteContact (int contactIndexInList)
        {
            phoneBookList.RemoveAt(contactIndexInList);
        }
    }
}
